var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["d2b5b473-d77f-4688-8549-c429db24ebb8","9396e0f0-f35c-42e3-8ac1-cc9129a98f76","6ac06308-ca8e-4fed-af9a-f261327b51eb","bf01f2ae-42f8-41a9-95f0-43de83e40fb7","a06be632-46c4-462d-9846-60f459bfe935","bde0e762-d1b4-4005-be79-012ffa0043b5"],"propsByKey":{"d2b5b473-d77f-4688-8549-c429db24ebb8":{"name":"kunai","sourceUrl":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/d2b5b473-d77f-4688-8549-c429db24ebb8.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"rbmW3DCy2NrnUiqxW1g6n55ctYlddatg","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/d2b5b473-d77f-4688-8549-c429db24ebb8.png"},"9396e0f0-f35c-42e3-8ac1-cc9129a98f76":{"name":"saseju-removebg-preview.png_1","sourceUrl":null,"frameSize":{"x":126,"y":508},"frameCount":1,"looping":true,"frameDelay":12,"version":"uwClleYVhUYdsb9uGWhiTuAvhRhKsvwF","loadedFromSource":true,"saved":true,"sourceSize":{"x":126,"y":508},"rootRelativePath":"assets/9396e0f0-f35c-42e3-8ac1-cc9129a98f76.png"},"6ac06308-ca8e-4fed-af9a-f261327b51eb":{"name":"orochi-removebg-preview (1).png_1","sourceUrl":null,"frameSize":{"x":90,"y":222},"frameCount":1,"looping":true,"frameDelay":12,"version":"OuZmFzAQCV1JUHjW1WYzD..WoEzb3t0b","loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":222},"rootRelativePath":"assets/6ac06308-ca8e-4fed-af9a-f261327b51eb.png"},"bf01f2ae-42f8-41a9-95f0-43de83e40fb7":{"name":"images-removebg-preview.png_1","sourceUrl":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/bf01f2ae-42f8-41a9-95f0-43de83e40fb7.png","frameSize":{"x":348,"y":145},"frameCount":1,"looping":true,"frameDelay":4,"version":"34gu.u6NofkUFTrwhEV4kPqlvGpoqboD","loadedFromSource":true,"saved":true,"sourceSize":{"x":348,"y":145},"rootRelativePath":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/bf01f2ae-42f8-41a9-95f0-43de83e40fb7.png"},"a06be632-46c4-462d-9846-60f459bfe935":{"name":"png-transparent-cloud-blue-sky-white-clouds-element-taobao-material-cloudy-sky-during-daytime-blue-chemical-element-atmosphere.png_1","sourceUrl":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/a06be632-46c4-462d-9846-60f459bfe935.png","frameSize":{"x":920,"y":698},"frameCount":1,"looping":true,"frameDelay":4,"version":"lv6qzbZ25R5gECSvkJw3A9E5Hii9K569","loadedFromSource":true,"saved":true,"sourceSize":{"x":920,"y":698},"rootRelativePath":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/a06be632-46c4-462d-9846-60f459bfe935.png"},"bde0e762-d1b4-4005-be79-012ffa0043b5":{"name":"terra.png_1","sourceUrl":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/bde0e762-d1b4-4005-be79-012ffa0043b5.png","frameSize":{"x":920,"y":324},"frameCount":1,"looping":true,"frameDelay":4,"version":"dQQpL4i4NUQZHW4.dgyrYmh7hRrsktBB","loadedFromSource":true,"saved":true,"sourceSize":{"x":920,"y":324},"rootRelativePath":"assets/v3/animations/BU8k_kFGozT7vtw6lkRH9SrtXf-IQ88KpcyKjbpZWBU/bde0e762-d1b4-4005-be79-012ffa0043b5.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var pontosTime1 = 0;
var céu = createSprite(215, 57, 400, 200);
céu.setAnimation("png-transparent-cloud-blue-sky-white-clouds-element-taobao-material-cloudy-sky-during-daytime-blue-chemical-element-atmosphere.png_1");
var terra = createSprite(205, 273, 400, 200);
terra.setAnimation("terra.png_1");
var fundo = createSprite(200, 200, 300, 300);
fundo.setAnimation("images-removebg-preview.png_1");
fundo.scale = 2;
var raquete1 = createSprite(27, 181, 40, 40);
raquete1.setAnimation("orochi-removebg-preview (1).png_1");
raquete1.scale = 0.5;
raquete1.shapeColor = "black";
var raquete2 = createSprite(362, 208, 40, 40);
raquete2.shapeColor = "yellow";
raquete2.setAnimation("saseju-removebg-preview.png_1");
raquete2.scale = 0.3;
var bola = createSprite(200, 200, 20, 20);
bola.setAnimation("kunai");
bola.scale = 0.1;
bola.shapeColor = "blue";
bola.velocityX = 3;
createEdgeSprites();
function draw() {
  text(pontosTime1, 240, 8);
  if (bola.isTouching(leftEdge)) {
    pontosTime1 = pontosTime1+1;
  }
  if (keyDown("space")) {
    playSound("https://www.youtube.com/watch?v=L135EsSZ_10", false);
  }
  if (bola.isTouching(raquete1)) {
    playSound("assets/category_jump/ninja_jump_2.mp3", false);
  }
  if (bola.isTouching(raquete2)) {
    playSound("assets/category_jump/ninja_jump_2.mp3", false);
  }
  raquete2. getSpeed (10)
  background("green");
  raquete2.y = World.mouseY
  bola.bounceOff(raquete1);
  drawSprites(); bola.bounceOff(raquete2);
  bola.bounceOff(topEdge);
  bola.bounceOff(bottomEdge);
  bola.bounceOff(leftEdge);
  bola.bounceOff(rightEdge);
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
