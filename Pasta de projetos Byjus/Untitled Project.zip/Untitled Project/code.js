var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["ecab59a0-6bde-4d8e-89ae-cb6c39a9513e","9adb35d4-9e3b-4154-8a67-bf30fd304e60","5855c691-1037-4549-89ea-c55def7eadd6","25067ec0-adff-48d1-97f2-017a75806771","69b248f3-7c30-4f44-9f8b-06ac5f9b2d82"],"propsByKey":{"ecab59a0-6bde-4d8e-89ae-cb6c39a9513e":{"name":"car_green_1","sourceUrl":null,"frameSize":{"x":70,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":".dWzMeblKApVIpHTwR8drb8dj4FhOU75","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":131},"rootRelativePath":"assets/ecab59a0-6bde-4d8e-89ae-cb6c39a9513e.png"},"9adb35d4-9e3b-4154-8a67-bf30fd304e60":{"name":"car_yellow_1","sourceUrl":null,"frameSize":{"x":70,"y":121},"frameCount":1,"looping":true,"frameDelay":12,"version":"Ze7TjqqOxHMhWqwzenaMv0GbUFZMgtu.","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":121},"rootRelativePath":"assets/9adb35d4-9e3b-4154-8a67-bf30fd304e60.png"},"5855c691-1037-4549-89ea-c55def7eadd6":{"name":"car_red_1","sourceUrl":null,"frameSize":{"x":70,"y":131},"frameCount":1,"looping":true,"frameDelay":12,"version":"0BHV4rrfdLUQwgvWS19MjmIcJQegaMRL","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":70,"y":131},"rootRelativePath":"assets/5855c691-1037-4549-89ea-c55def7eadd6.png"},"25067ec0-adff-48d1-97f2-017a75806771":{"name":"blue_hanbok_1","sourceUrl":"assets/api/v1/animation-library/gamelab/Y9W1buVxqSA0MQdQvJOZmb2LYwFcmuZX/category_people/blue_hanbok.png","frameSize":{"x":167,"y":398},"frameCount":1,"looping":true,"frameDelay":2,"version":"Y9W1buVxqSA0MQdQvJOZmb2LYwFcmuZX","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":167,"y":398},"rootRelativePath":"assets/api/v1/animation-library/gamelab/Y9W1buVxqSA0MQdQvJOZmb2LYwFcmuZX/category_people/blue_hanbok.png"},"69b248f3-7c30-4f44-9f8b-06ac5f9b2d82":{"name":"commercial_05_1","sourceUrl":"assets/api/v1/animation-library/gamelab/7iRvQOk_CQWZ2zZMBuRIqLjJ9UbS9AoR/category_buildings/commercial_05.png","frameSize":{"x":400,"y":218},"frameCount":1,"looping":true,"frameDelay":2,"version":"7iRvQOk_CQWZ2zZMBuRIqLjJ9UbS9AoR","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":218},"rootRelativePath":"assets/api/v1/animation-library/gamelab/7iRvQOk_CQWZ2zZMBuRIqLjJ9UbS9AoR/category_buildings/commercial_05.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var rodovia = createSprite(200, 200, 900, 300);
rodovia.shapeColor = "black";
var Barra = createSprite(216, 340, 500, 20);
Barra.shapeColor = "grey";
var Barra = createSprite(190, 61, 500, 30);
Barra.shapeColor = "grey";
var Sam = createSprite(35, 169, 20, 30);
Sam.scale = 0.2;
Sam.setAnimation("blue_hanbok_1");
var carroVermelho = createSprite(298, 282, 30, 30);
carroVermelho.scale = 0.5;
carroVermelho.setAnimation("car_red_1");
carroVermelho.shapeColor = "red";
var carroAmarelo = createSprite(220, 286, 30, 30);
carroAmarelo.scale = 0.5;
carroAmarelo.setAnimation("car_yellow_1");
carroAmarelo.shapeColor = "yellow";
var carroVerde = createSprite(147, 283, 30, 30);
carroVerde.scale = 0.5;
carroVerde.setAnimation("car_green_1");
carroVerde.shapeColor = "green";
function draw() {
if (keyDown("right")) {
  Sam.x = Sam.x+3;}
if (keyDown("left")) {
  Sam.x = Sam.x-3;
}
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
